LINEAR ORÇAMENTOS CLOUD V6

O que foi adicionado:
- Backup automático via GitHub Gist.
- Sincronização real entre celular, notebook e computador.
- Produtos ligados aos itens do orçamento.
- PDF com dados da LINEAR MOVEIS PLANEJADOS LTDA.
- PWA: pode instalar no celular pela opção “Adicionar à tela inicial”.

Como usar sem pagar domínio:
1. Crie uma conta no GitHub.
2. Crie um repositório novo, por exemplo: linear-orcamentos-cloud.
3. Envie todos os arquivos desta pasta para o repositório.
4. No GitHub, vá em Settings > Pages.
5. Em Source, escolha Deploy from a branch, branch main, pasta /root.
6. O GitHub vai gerar um link parecido com:
   https://seuusuario.github.io/linear-orcamentos-cloud/

Como ativar backup e sincronização:
1. No GitHub, crie um token com permissão Gist.
2. Abra o app pelo link do GitHub Pages.
3. Vá em Backup/Sincronização.
4. Cole o token.
5. Clique em Salvar configuração.
6. Clique em Criar backup no GitHub.
7. O sistema vai gerar um Gist ID automaticamente.
8. Guarde esse Gist ID.

Em outro dispositivo:
1. Abra o mesmo link do GitHub Pages.
2. Vá em Backup/Sincronização.
3. Cole o mesmo token e Gist ID.
4. Clique em Baixar dados da nuvem.

Observação importante:
O GitHub é usado como backup/sincronização. Para segurança, o token fica salvo apenas no navegador de cada aparelho. Não publique o token em prints, vídeos ou arquivos.
